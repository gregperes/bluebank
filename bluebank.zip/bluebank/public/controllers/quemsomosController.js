app.controller("quemsomosController", function ($scope) {

});